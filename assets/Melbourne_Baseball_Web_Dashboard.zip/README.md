# Melbourne Baseball Club — Browser Dashboard

This is a static HTML/JavaScript replacement for the original Shiny viewer. No R, RStudio, server, or build process is required.

## Open locally
Double-click `index.html` to view the interactive dashboard. Reports are in `reports/`; data in `data/dashboard.json`.

## Publish
Upload the folder contents to a static web host (GitHub Pages, Cloudflare Pages, Netlify, Vercel, etc.). For GitHub Pages, put `index.html`, `data/`, and `reports/` at the repository root and enable Pages from the main branch.

## Limitations
The original Shiny source package provided five-game Sandringham batting/pitching CSVs, report PDFs, and Melbourne season PDFs, not complete normalized game-by-game Melbourne player data. This conversion preserves that limitation and does not fabricate missing data.

## Security
No shinyapps.io or other deployment credentials are included.
